=== WooCommerce Alta Demanda ===
Contributors: tu-usuario-wporg
Tags: woocommerce, pedidos, alta demanda
Requires at least: 5.6
Tested up to: 6.2
Stable tag: 1.3.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Controla la cantidad de pedidos en períodos de alta demanda, mostrando alertas globales y deshabilitando el checkout si se alcanza el límite. Permite configurar qué estados de pedido contar, colores, texto de alerta y transiciones. Incluye enlace directo a Ajustes desde la lista de plugins.

== Installation ==
1. Sube la carpeta `woocommerce-alta-demanda` a `wp-content/plugins`.
2. Activa el plugin desde la pantalla “Plugins” en tu WordPress.
3. Configura los límites y opciones en “WooCommerce > Ajustes > Alta Demanda”.

== Frequently Asked Questions ==
= ¿Cómo se calcula el bloqueo? =
Se revisa la cantidad de pedidos recientes en el período corto y largo. Si se exceden los máximos configurados, el botón de pago se deshabilita temporalmente.

== Changelog ==
= 1.3.2 =
* Separación de JS y CSS en archivos propios.
* Ajustes de la clase principal y readme.txt para cumplir con buenas prácticas.

== Upgrade Notice ==
= 1.3.2 =
Se recomienda actualizar para tener la versión con mejoras en la organización del código y la compatibilidad con WordPress 6.2.
