<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente
}

class WC_Alta_Demanda {

    private $max_pedidos_corto;
    private $periodo_corto;   // Guardado en segundos internamente
    private $max_pedidos_largo;
    private $periodo_largo;   // Guardado en segundos internamente

    // Opciones de color
    private $color_fondo;
    private $color_texto;
    private $color_borde;

    // Texto de alerta
    private $alert_text;

    public function __construct() {
        // Cargar opciones numéricas
        $this->max_pedidos_corto = (int) get_option( 'wc_alta_demanda_max_pedidos_corto', 10 );
        $this->periodo_corto     = (int) get_option( 'wc_alta_demanda_periodo_corto', 10 ) * 60;

        $this->max_pedidos_largo = (int) get_option( 'wc_alta_demanda_max_pedidos_largo', 50 );
        $this->periodo_largo     = (int) get_option( 'wc_alta_demanda_periodo_largo', 60 ) * 60;

        // Cargar opciones de color
        $this->color_fondo = get_option( 'wc_alta_demanda_color_fondo', '#fff3cd' );
        $this->color_texto = get_option( 'wc_alta_demanda_color_texto', '#000000' );
        $this->color_borde = get_option( 'wc_alta_demanda_color_borde', '#f5c518' );

        // Cargar el texto de alerta
        $this->alert_text = get_option(
            'wc_alta_demanda_alert_text',
            '¡Atención! Debido a alta demanda, el proceso de pago está deshabilitado. Por favor espere {MINUTOS}.'
        );

        // Si la funcionalidad está activada
        if ( get_option( 'wc_alta_demanda_enabled', 0 ) ) {
            add_action( 'wp_ajax_wc_verificar_bloqueo', [ $this, 'verificar_estado' ] );
            add_action( 'wp_ajax_nopriv_wc_verificar_bloqueo', [ $this, 'verificar_estado' ] );

            add_action( 'woocommerce_review_order_before_submit', [ $this, 'deshabilitar_boton_checkout' ] );
            add_action( 'woocommerce_checkout_process', [ $this, 'bloquear_checkout_si_es_necesario' ] );

            // Muestra la alerta global en el frontend
            add_action( 'wp_footer', [ $this, 'mostrar_alerta_global' ] );
        }

        // Integramos la configuración en una pestaña de WooCommerce
        add_filter( 'woocommerce_settings_tabs_array', [ $this, 'add_settings_tab' ], 50 );
        add_action( 'woocommerce_settings_tabs_alta_demanda', [ $this, 'settings_tab' ] );
        add_action( 'woocommerce_update_options_alta_demanda', [ $this, 'update_settings' ] );

        // Encolar el color picker en la pantalla de ajustes
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_color_picker' ] );
    }

    /**
     * Agrega la pestaña "Alta Demanda" a la configuración de WooCommerce.
     */
    public function add_settings_tab( $settings_tabs ) {
        $settings_tabs['alta_demanda'] = __( 'Alta Demanda', 'woocommerce-alta-demanda' );
        return $settings_tabs;
    }

    /**
     * Encolar el color picker de WordPress en la pestaña "Alta Demanda".
     */
    public function enqueue_color_picker( $hook ) {
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'wc-settings'
             && isset( $_GET['tab'] ) && $_GET['tab'] === 'alta_demanda' ) {

            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'wp-color-picker' );

            $script = "
                jQuery(function($){
                    $('.wc-alta-demanda-colorpicker').wpColorPicker({
                        change: function(event, ui) {
                            $(event.target).val(ui.color.toString()).trigger('change');
                        },
                        clear: function() {
                            $(this).val('').trigger('change');
                        }
                    });
                });
            ";
            wp_add_inline_script( 'wp-color-picker', $script );
        }
    }

    /**
     * Muestra el formulario de configuración en la pestaña "Alta Demanda".
     */
    public function settings_tab() {
        // Obtener la lista de estados de pedido con su etiqueta
        $all_order_statuses = wc_get_order_statuses(); 
        $selected_statuses = get_option( 'wc_alta_demanda_order_statuses', [ 'processing', 'completed' ] );
        ?>
        <h2><?php esc_html_e( 'Configuración de Alta Demanda', 'woocommerce-alta-demanda' ); ?></h2>

        <table class="form-table">
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Habilitar Alta Demanda', 'woocommerce-alta-demanda' ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Activar restricciones de alta demanda en la tienda.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <input type="checkbox" name="wc_alta_demanda_enabled" value="1" <?php checked( get_option( 'wc_alta_demanda_enabled', 0 ), 1 ); ?> />
                    <span class="description"><?php esc_html_e( 'Activar restricciones de alta demanda.', 'woocommerce-alta-demanda' ); ?></span>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Máximo de pedidos en período corto', 'woocommerce-alta-demanda' ); ?>
					<span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Establece la cantidad máxima de pedidos que pueden realizarse dentro de un lapso de tiempo breve.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <input type="number" name="wc_alta_demanda_max_pedidos_corto" value="<?php echo esc_attr( get_option( 'wc_alta_demanda_max_pedidos_corto', 10 ) ); ?>" required />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Período corto (minutos)', 'woocommerce-alta-demanda' ); ?>
					<span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Define la duración (en minutos) del período breve durante el cual se miden los pedidos.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <input type="number" name="wc_alta_demanda_periodo_corto" value="<?php echo esc_attr( get_option( 'wc_alta_demanda_periodo_corto', 10 ) ); ?>" required />
                </td>
            </tr>

            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Máximo de pedidos en período largo', 'woocommerce-alta-demanda' ); ?>
					<span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Indica cuántos pedidos se pueden realizar como máximo dentro del lapso de tiempo “largo”.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <input type="number" name="wc_alta_demanda_max_pedidos_largo" value="<?php echo esc_attr( get_option( 'wc_alta_demanda_max_pedidos_largo', 50 ) ); ?>" required />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Período largo (minutos)', 'woocommerce-alta-demanda' ); ?>
					<span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Establece el rango de tiempo más amplio (en minutos) para el que se evalúa el número de pedidos.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <input type="number" name="wc_alta_demanda_periodo_largo" value="<?php echo esc_attr( get_option( 'wc_alta_demanda_periodo_largo', 60 ) ); ?>" required />
                </td>
            </tr>

            <!-- Texto de alerta -->
            <tr valign="top">
                <th colspan="2">
                    <h2><?php esc_html_e( 'Texto de la Alerta', 'woocommerce-alta-demanda' ); ?></h2>
                </th>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Texto base de la alerta', 'woocommerce-alta-demanda' ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php esc_attr_e( 'Puedes incluir {MINUTOS} para mostrar el tiempo estimado.', 'woocommerce-alta-demanda' ); ?>"></span>
                </th>
                <td>
                    <textarea name="wc_alta_demanda_alert_text" rows="3" style="width: 100%;"><?php echo esc_textarea( $this->alert_text ); ?></textarea>
                    <p class="description">
                        <?php esc_html_e( 'Usa {MINUTOS} donde quieras que aparezca el tiempo estimado.', 'woocommerce-alta-demanda' ); ?>
                    </p>
                </td>
            </tr>

         <!-- Estados de pedido a considerar -->
<tr valign="top">
    <th colspan="2">
        <h2><?php esc_html_e( 'Estados de pedido a considerar', 'woocommerce-alta-demanda' ); ?></h2>
        <p class="description">
            <?php esc_html_e( 'Selecciona los estados de pedido que contarán para el bloqueo.', 'woocommerce-alta-demanda' ); ?>
        </p>
    </th>
</tr>
<tr valign="top">
    <th scope="row" style="vertical-align: top;">
        <?php esc_html_e( 'Estados de pedido', 'woocommerce-alta-demanda' ); ?>
    </th>
    <td>
        <?php 
        // Si la opción no existe o está vacía, usamos los valores predeterminados
        $selected_statuses = get_option('wc_alta_demanda_order_statuses');
        if ( ! is_array( $selected_statuses ) || empty( $selected_statuses ) ) {
            $selected_statuses = array( 'processing', 'completed' );
        }

        foreach ( $all_order_statuses as $status_key => $status_label ) : 
            // Removemos el prefijo "wc-" para la comparación
            $status_without_prefix = str_replace( 'wc-', '', $status_key );
            $checked = in_array( $status_without_prefix, $selected_statuses, true ) ? 'checked' : '';
            ?>
            <label style="display:block; margin-bottom:4px;">
                <input 
                    type="checkbox"
                    name="wc_alta_demanda_order_statuses[]"
                    value="<?php echo esc_attr( $status_without_prefix ); ?>"
                    <?php echo $checked; ?>
                />
                <?php echo esc_html( $status_label ); ?>
            </label>
        <?php endforeach; ?>
    </td>
</tr>


            <!-- Opciones de colores -->
            <tr valign="top">
                <th colspan="2">
                    <h2><?php esc_html_e( 'Opciones de Colores', 'woocommerce-alta-demanda' ); ?></h2>
                </th>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Color de fondo del mensaje', 'woocommerce-alta-demanda' ); ?>
                </th>
                <td>
                    <input 
                        type="text" 
                        name="wc_alta_demanda_color_fondo" 
                        class="wc-alta-demanda-colorpicker" 
                        value="<?php echo esc_attr( get_option( 'wc_alta_demanda_color_fondo', '#fff3cd' ) ); ?>" 
                    />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Color de texto del mensaje', 'woocommerce-alta-demanda' ); ?>
                </th>
                <td>
                    <input 
                        type="text" 
                        name="wc_alta_demanda_color_texto" 
                        class="wc-alta-demanda-colorpicker"
                        value="<?php echo esc_attr( get_option( 'wc_alta_demanda_color_texto', '#000000' ) ); ?>" 
                    />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <?php esc_html_e( 'Color de borde del mensaje', 'woocommerce-alta-demanda' ); ?>
                </th>
                <td>
                    <input 
                        type="text" 
                        name="wc_alta_demanda_color_borde" 
                        class="wc-alta-demanda-colorpicker"
                        value="<?php echo esc_attr( get_option( 'wc_alta_demanda_color_borde', '#f5c518' ) ); ?>" 
                    />
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Guarda la configuración al presionar "Guardar cambios".
     */
    public function update_settings() {
        update_option( 'wc_alta_demanda_enabled', isset( $_POST['wc_alta_demanda_enabled'] ) ? 1 : 0 );
        update_option( 'wc_alta_demanda_max_pedidos_corto', (int) $_POST['wc_alta_demanda_max_pedidos_corto'] );
        update_option( 'wc_alta_demanda_periodo_corto', (int) $_POST['wc_alta_demanda_periodo_corto'] );
        update_option( 'wc_alta_demanda_max_pedidos_largo', (int) $_POST['wc_alta_demanda_max_pedidos_largo'] );
        update_option( 'wc_alta_demanda_periodo_largo', (int) $_POST['wc_alta_demanda_periodo_largo'] );

        if ( isset( $_POST['wc_alta_demanda_alert_text'] ) ) {
            update_option( 'wc_alta_demanda_alert_text', wp_kses_post( wp_unslash( $_POST['wc_alta_demanda_alert_text'] ) ) );
        }

        if ( isset( $_POST['wc_alta_demanda_color_fondo'] ) ) {
            update_option( 'wc_alta_demanda_color_fondo', sanitize_text_field( $_POST['wc_alta_demanda_color_fondo'] ) );
        }
        if ( isset( $_POST['wc_alta_demanda_color_texto'] ) ) {
            update_option( 'wc_alta_demanda_color_texto', sanitize_text_field( $_POST['wc_alta_demanda_color_texto'] ) );
        }
        if ( isset( $_POST['wc_alta_demanda_color_borde'] ) ) {
            update_option( 'wc_alta_demanda_color_borde', sanitize_text_field( $_POST['wc_alta_demanda_color_borde'] ) );
        }

        if ( isset( $_POST['wc_alta_demanda_order_statuses'] ) ) {
            $statuses_array = array_map( 'sanitize_text_field', (array) $_POST['wc_alta_demanda_order_statuses'] );
            update_option( 'wc_alta_demanda_order_statuses', $statuses_array );
        } else {
            update_option( 'wc_alta_demanda_order_statuses', [] );
        }

        $this->alert_text = get_option( 'wc_alta_demanda_alert_text' );
    }

    /**
     * Verifica el estado de alta demanda mediante AJAX.
     */
    public function verificar_estado() {
        if ( ! get_option( 'wc_alta_demanda_enabled', 1 ) ) {
            wp_send_json( [
                'bloqueado'          => false,
                'triggeredCondition' => 'ninguno',
                'shortPeriod'        => 0,
                'longPeriod'         => 0
            ] );
        }

        $selected_statuses = get_option( 'wc_alta_demanda_order_statuses', [ 'processing', 'completed' ] );

        $pedidos = wc_get_orders( [
            'limit'   => $this->max_pedidos_largo,
            'orderby' => 'date',
            'order'   => 'DESC',
            'status'  => $selected_statuses,
        ] );

        if ( empty( $pedidos ) ) {
            wp_send_json( [
                'bloqueado'          => false,
                'triggeredCondition' => 'ninguno',
                'shortPeriod'        => 0,
                'longPeriod'         => 0
            ] );
        }

        $pedidos_corto = array_filter( $pedidos, function( $p ) {
            return strtotime( $p->get_date_created() ) > ( time() - $this->periodo_corto );
        } );
        $pedidos_largo = array_filter( $pedidos, function( $p ) {
            return strtotime( $p->get_date_created() ) > ( time() - $this->periodo_largo );
        } );

        $bloqueo_activo_corto = ( count( $pedidos_corto ) >= $this->max_pedidos_corto );
        $bloqueo_activo_largo = ( count( $pedidos_largo ) >= $this->max_pedidos_largo );
        $bloqueo_activo       = ( $bloqueo_activo_corto || $bloqueo_activo_largo );

        $triggeredCondition = 'ninguno';
        if ( $bloqueo_activo_corto && $bloqueo_activo_largo ) {
            $triggeredCondition = 'ambos';
        } elseif ( $bloqueo_activo_corto ) {
            $triggeredCondition = 'corto';
        } elseif ( $bloqueo_activo_largo ) {
            $triggeredCondition = 'largo';
        }

        wp_send_json( [
            'bloqueado'          => $bloqueo_activo,
            'triggeredCondition' => $triggeredCondition,
            'shortPeriod'        => $this->periodo_corto,
            'longPeriod'         => $this->periodo_largo
        ] );
    }

    /**
     * Inyecta un script en el checkout para deshabilitar el botón si se detecta alta demanda.
     */
    public function deshabilitar_boton_checkout() {
        if ( ! get_option( 'wc_alta_demanda_enabled', 1 ) ) {
            return;
        }
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($){
            $.ajax({
                url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
                type: "POST",
                data: { action: "wc_verificar_bloqueo" },
                success: function(response) {
                    if ( response.bloqueado ) {
                        $('form.checkout').find(':input[type="submit"]').prop('disabled', true);
                    }
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Bloquea el checkout durante el proceso si se detecta alta demanda.
     */
    public function bloquear_checkout_si_es_necesario() {
        if ( ! get_option( 'wc_alta_demanda_enabled', 1 ) ) {
            return;
        }

        $selected_statuses = get_option( 'wc_alta_demanda_order_statuses', [ 'processing', 'completed' ] );

        $pedidos = wc_get_orders( [
            'limit'   => $this->max_pedidos_largo,
            'orderby' => 'date',
            'order'   => 'DESC',
            'status'  => $selected_statuses,
        ] );

        if ( empty( $pedidos ) ) {
            return;
        }

        $pedidos_corto = array_filter( $pedidos, function( $p ) {
            return strtotime( $p->get_date_created() ) > ( time() - $this->periodo_corto );
        } );
        $pedidos_largo = array_filter( $pedidos, function( $p ) {
            return strtotime( $p->get_date_created() ) > ( time() - $this->periodo_largo );
        } );

        $bloqueo_activo_corto = ( count( $pedidos_corto ) >= $this->max_pedidos_corto );
        $bloqueo_activo_largo = ( count( $pedidos_largo ) >= $this->max_pedidos_largo );

        if ( $bloqueo_activo_corto || $bloqueo_activo_largo ) {
            wc_add_notice(
                __( 'Debido a alta demanda, el proceso de pago está temporalmente deshabilitado. Inténtelo más tarde.', 'woocommerce-alta-demanda' ),
                'error'
            );
        }
    }

    /**
     * Muestra una alerta global en el frontend y la actualiza cada 60 segundos.
     */
    public function mostrar_alerta_global() {
        if ( ! get_option( 'wc_alta_demanda_enabled', 1 ) ) {
            return;
        }

        $bg_color     = esc_attr( $this->color_fondo );
        $text_color   = esc_attr( $this->color_texto );
        $border_color = esc_attr( $this->color_borde );
        $alert_text_js = esc_js( $this->alert_text );
        ?>
        <script type="text/javascript">
        (function($){
            function formatTimeToLargestUnit(m) {
                if ( m >= 1440 ) {
                    var days = Math.floor(m / 1440);
                    return days + " " + (days === 1 ? "día" : "días");
                } else if ( m >= 60 ) {
                    var hours = Math.floor(m / 60);
                    return hours + " " + (hours === 1 ? "hora" : "horas");
                } else {
                    return m + " " + (m === 1 ? "minuto" : "minutos");
                }
            }

            function checkDemandStatus() {
                $.ajax({
                    url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
                    type: "POST",
                    data: { action: "wc_verificar_bloqueo" },
                    success: function(response) {
                        if ( ! response.bloqueado ) {
                            if ( $('#global-alta-demanda-alert').length ) {
                                $('#global-alta-demanda-alert').fadeOut('slow', function(){
                                    $(this).remove();
                                });
                            }
                            $('form.checkout').find(':input[type="submit"]').prop('disabled', false);
                        } else {
                            var messageBase = "<?php echo $alert_text_js; ?>";
                            var shortMins = Math.ceil(response.shortPeriod / 60);
                            var longMins  = Math.ceil(response.longPeriod / 60);
                            var timeToWait = 0;
                            if ( response.triggeredCondition === 'corto' ) {
                                timeToWait = shortMins;
                            } else if ( response.triggeredCondition === 'largo' ) {
                                timeToWait = longMins;
                            } else if ( response.triggeredCondition === 'ambos' ) {
                                timeToWait = Math.max(shortMins, longMins);
                            }
                            var prettyTime = formatTimeToLargestUnit(timeToWait);
                            var finalMessage = messageBase.replace(/\{MINUTOS\}/g, prettyTime);
                            
                            if ( ! $('#global-alta-demanda-alert').length ) {
                                $('body').prepend(
                                    '<div id="global-alta-demanda-alert" style="display:none; position:relative; width:100%; box-sizing:border-box; background:' + '<?php echo $bg_color; ?>' + '; color:' + '<?php echo $text_color; ?>' + '; border:2px solid ' + '<?php echo $border_color; ?>' + '; padding:15px; text-align:center; font-weight:bold; z-index:9999;">' +
                                    finalMessage +
                                    '</div>'
                                );
                                $('#global-alta-demanda-alert').fadeIn('slow');
                            } else {
                                $('#global-alta-demanda-alert').stop(true, true).fadeIn('fast').html(finalMessage);
                            }
                            $('form.checkout').find(':input[type="submit"]').prop('disabled', true);
                        }
                    }
                });
            }

            $(document).ready(function(){
                checkDemandStatus();
                setInterval(checkDemandStatus, 60000);
            });
        })(jQuery);
        </script>
        <?php
    }
}
