<?php
/**
 * Plugin Name: WooCommerce Alta Demanda
 * Description: Controla la cantidad de pedidos en períodos de alta demanda, mostrando alertas globales y deshabilitando el botón pagar si se alcanza el límite. Permite configurar qué estados de pedido contar, colores y texto de alerta.
 * Version: 1.3.3
 * Author: Juan Carlos Donderiz de la Cruz
 * Text Domain: woocommerce-alta-demanda
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente
}

// Agregar enlace "Ajustes" en la lista de plugins
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_alta_demanda_plugin_action_links' );
function wc_alta_demanda_plugin_action_links( $links ) {
    $settings_url = admin_url( 'admin.php?page=wc-settings&tab=alta_demanda' );
    $links[] = '<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Ajustes', 'woocommerce-alta-demanda' ) . '</a>';
    return $links;
}

// Cargar la clase principal del plugin
if ( ! class_exists( 'WC_Alta_Demanda' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-wc-alta-demanda.php';
}

// Inicializar el plugin una vez cargados todos los plugins
add_action( 'plugins_loaded', 'wc_alta_demanda_init_plugin', 11 );
function wc_alta_demanda_init_plugin() {
    // Verificar si WooCommerce está activo
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="error"><p>' . esc_html__( 'WooCommerce Alta Demanda requiere que WooCommerce esté instalado y activo.', 'woocommerce-alta-demanda' ) . '</p></div>';
        } );
        return;
    }
    new WC_Alta_Demanda();
}
